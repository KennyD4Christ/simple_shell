#include "shell.h"

/**
 *  * read_line - Read a line from the standard input
 *   *
 *    * Return: The read line as a string
 */
char *read_line(void)
{
return (custom_getline());
}
